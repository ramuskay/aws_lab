'use strict';
console.log('Loading tax calculator function...');
exports.handler = (event, context, callback) => {
    console.log('Received event: ', JSON.stringify(event, null,
        2));
    try {
        console.log(`Product price: $${event.productPrice}`);
        console.log(`Tax rate: ${event.taxRate}%`);
        console.log(`Surcharge rate: ${event.surchargeRate}%`);
        let tax = event.productPrice * (event.taxRate / 100.00);
        let surcharge = event.productPrice * (event.surchargeRate
            / 100.00);
        let finalPrice = event.productPrice + tax + surcharge;
        console.log(`Final price with tax: $${finalPrice}`);
        // On success, invoke the callback like so (2 arguments)
        // first one being null.
        callback(null, finalPrice); // Return calculated tax
    }
    catch (e) {
        console.log(e);
        // On failure, invoke the callback like so (a singleargument)
        // with a helpful error message.
        callback('ERROR: Something went wrong!');
    }
    console.log("Done calculating tax.");
};